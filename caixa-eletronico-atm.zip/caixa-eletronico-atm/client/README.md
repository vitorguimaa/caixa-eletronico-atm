# ATM Simulator Client

## Configuração

1. Instale as dependências:
```bash
npm install
