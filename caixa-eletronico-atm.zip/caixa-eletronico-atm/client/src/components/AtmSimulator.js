import React, { useState } from 'react';

const AtmSimulator = () => {
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState({});
  const [balance, setBalance] = useState(null);
  const [error, setError] = useState('');

  const handleWithdraw = async () => {
    try {
      const response = await fetch('/api/atm/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: parseInt(amount) }),
      });
      const data = await response.json();
      if (response.ok) {
        setNotes(data.notes);
        setBalance(data.balance);
        setError('');
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Erro na conexão com o servidor');
    }
  };

  const handleCheckBalance = async () => {
    try {
      const response = await fetch('/api/atm/balance');
      const data = await response.json();
      setBalance(data.balance);
    } catch (err) {
      setError('Erro na conexão com o servidor');
    }
  };

  return (
    <div>
      <h1>ATM Simulator</h1>
      <div>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Digite o valor do saque"
        />
        <button onClick={handleWithdraw}>Sacar</button>
      </div>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {notes && (
        <div>
          <h3>Notas Entregues:</h3>
          <ul>
            {Object.entries(notes).map(([note, count]) => (
              <li key={note}>
                {count} nota(s) de R${note}
              </li>
            ))}
          </ul>
        </div>
      )}
      <div>
        <button onClick={handleCheckBalance}>Consultar Saldo</button>
        {balance !== null && <p>Saldo: R${balance}</p>}
      </div>
    </div>
  );
};

export default AtmSimulator;
