import React from 'react';
import AtmSimulator from './components/AtmSimulator';

const App = () => (
  <div>
    <AtmSimulator />
  </div>
);

export default App;
