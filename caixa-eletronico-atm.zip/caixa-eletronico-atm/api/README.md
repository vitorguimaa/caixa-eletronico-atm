# ATM Simulator API

## Configuração

1. Instale as dependências:
```bash
npm install
