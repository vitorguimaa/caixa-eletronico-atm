const express = require('express');
const { withdraw, getBalance } = require('../controllers/atmController');
const router = express.Router();

router.post('/withdraw', withdraw);
router.get('/balance', getBalance);

module.exports = router;
