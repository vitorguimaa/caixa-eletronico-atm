const Account = require('../models/account');

const getNotes = (amount) => {
  const notes = [100, 50, 20, 10];
  const result = {};
  for (let note of notes) {
    result[note] = Math.floor(amount / note);
    amount %= note;
  }
  return result;
};

exports.withdraw = async (req, res) => {
  const { amount } = req.body;
  if (amount % 10 !== 0) {
    return res.status(400).send({ error: 'Amount must be multiple of 10' });
  }

  const account = await Account.findOne();
  if (!account || account.balance < amount) {
    return res.status(400).send({ error: 'Insufficient funds' });
  }

  account.balance -= amount;
  await account.save();

  const notes = getNotes(amount);
  res.send({ notes, balance: account.balance });
};

exports.getBalance = async (req, res) => {
  const account = await Account.findOne();
  res.send({ balance: account ? account.balance : 0 });
};
